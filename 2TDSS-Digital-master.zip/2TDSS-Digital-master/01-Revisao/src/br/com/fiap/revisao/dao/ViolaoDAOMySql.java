package br.com.fiap.revisao.dao;

import java.util.List;
import br.com.fiap.revisao.bean.Violao;

//Uma classe pode herdar de uma classe
//Uma classe pode implementar uma ou mais interfaces
public class ViolaoDAOMySql implements ViolaoDAO {

	@Override
	public void insert(Violao violao) {
		// TODO Auto-generated method stub
	}

	@Override
	public List<Violao> list() {
		// TODO Auto-generated method stub
		return null;
	}

}